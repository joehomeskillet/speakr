# Account Settings

Your account settings are the control center for personalizing Speakr to work exactly how you need it. Every preference you set here shapes your daily experience, from the language you see to how AI summarizes your recordings. Access these settings by clicking your username in the top navigation and selecting Account.

## Account Information Tab

![Account Information](../assets/images/screenshots/settings-account-info.png)

The Account Information tab presents a comprehensive view of your profile, statistics, and account actions.

### Personal Information

On the left side, you'll find fields to update your full name, job title, and company or organization. These details help identify you in collaborative environments and provide context for your recordings. Keeping these current ensures colleagues can recognize your contributions and administrators can manage users effectively.

Language preferences (interface language, default transcription language, and preferred output language) live on the **Preferences** tab. See the [Preferences Tab](#preferences-tab) section below.

### Account Statistics

The right side displays your recording metrics at a glance. You'll see your total recordings count and how many have been completed processing. Below that, the number of recordings currently processing and any that have failed provide immediate insight into your content status.

### User Details

Your username and email address appear here as read-only fields. The email serves as your sign-in credential and cannot be changed without administrator assistance.

### Processing Preferences

Control how your recordings are automatically processed:

#### Auto-Summarization

The **Auto-Summarization** toggle controls whether summaries are automatically generated after transcription completes. When enabled (the default), every recording receives an AI-generated summary using your custom prompt or the system default. Disable this if you prefer to manually trigger summarization or if you only need transcripts.

#### Auto Speaker Labeling

When you have speaker voice profiles with embeddings (from WhisperX ASR), the **Auto Speaker Labeling** feature can automatically identify and label speakers in new recordings.

- **Enable/Disable** - Toggle automatic speaker identification
- **Confidence Threshold** - Choose how strict the matching should be:
  - **Low** - More matches, but may have false positives
  - **Medium** - Balanced accuracy (recommended)
  - **High** - Fewer matches, but higher confidence

Auto speaker labeling works by comparing voice embeddings from the new recording against your saved speaker profiles. When a match exceeds your confidence threshold, the speaker is automatically labeled with the known name.

!!! tip "Building Voice Profiles"
    Auto speaker labeling requires voice profiles with embeddings. These are created when you identify speakers in recordings processed with WhisperX ASR (with `ASR_RETURN_SPEAKER_EMBEDDINGS=true`). The more recordings you identify a speaker in, the better the matching becomes.

### Account Actions

The account actions section provides quick access to essential functions. The prominent "Go to recordings" button takes you directly to your recording library. The "Change password" button opens a secure dialog for updating your credentials. The "Manage speakers" link provides a shortcut to speaker profile management, though this functionality is also accessible via its dedicated tab.

## Custom Prompts Tab

![Custom Prompts](../assets/images/screenshots/custom-summary-prompt.png)

The Custom Prompts tab unlocks one of Speakr's most powerful features - the ability to shape how AI interprets and summarizes your recordings.

### Your Custom Summary Prompt

The large text area accepts detailed instructions in natural language that become the AI's instruction set. Think of it as teaching an assistant exactly how you want meeting notes prepared. You might request specific sections like "Key Technical Decisions" for engineering meetings or "Patient Observations" for medical consultations.

### Current Default Prompt

Below your custom prompt area, you'll see the default prompt that applies when you leave yours blank. This transparency shows exactly what baseline instructions the AI follows - typically requesting key issues, decisions, and action items. Use this as a foundation to build upon or completely replace with your own approach.

### Prompt Hierarchy

Understanding prompt precedence helps you use this feature effectively. Tag prompts have the highest priority - when you tag a recording with "Legal" or "Sales," any prompts associated with those tags override everything else. Your personal custom prompt comes next, applying to all recordings without tag-specific prompts. Below that sits the admin default set by your Speakr administrator, with a system fallback ensuring summaries always generate.

### Prompt Stacking

Multiple tag prompts combine intelligently when applied together. A recording tagged with both "Client" and "Technical" receives both sets of instructions, creating comprehensive summaries without needing complex single prompts trying to cover every scenario.

### Title Prompt

The **Title prompt** field sets the instructions for the titles Speakr generates for your recordings. Leave it blank to use the current default, which is shown below the field. Only the instructions are yours to change: the transcript, your output language and the rule that the model replies with the title alone are added automatically.

Title prompts follow the same precedence as summary prompts. A tag's title prompt applies first (several tags with title prompts combine, in the order the tags were added), then the folder's, then yours, then the administrator's default, and finally the built-in default. Tags and folders have a **Title prompt** field next to their summary prompt for this purpose. A naming template (Account → Templates → Recording Titles) still controls the final title format, and its `{{ai_title}}` placeholder is filled with the title these instructions produce.

The naming template comes from the first tag on the recording that has one, then from the recording's folder, then from your default template. The same template is applied when you regenerate a title from the recording header. When a recording is processed again, for example after you reprocess its transcription, a generated title is generated again with the current tags and templates; a title you typed or edited is kept. A merged recording without a typed title is titled the same way as an upload.

### Transcription Hints

Below the summary prompt, you'll find the **Transcription hints** section with two fields that help improve transcription accuracy:

- **Default hotwords** - A comma-separated list of words or phrases the transcription engine should prioritize, such as brand names, acronyms, or specialized terminology (e.g., `Speakr, CTranslate2, PyAnnote`).
- **Default initial prompt** - A brief description of the typical content of your recordings that provides context to the transcription engine (e.g., "This is a meeting about software development and AI tools.").

These defaults apply to all your recordings unless overridden by tag defaults, folder defaults, or values you set in the upload form's Advanced ASR Options. This is the lowest priority level in the precedence hierarchy, making it a good place to set general-purpose hints that apply across most of your content.

!!! tip "When to use hotwords vs initial prompt"
    Use **hotwords** for specific terms the model tends to misspell - proper nouns, brand names, technical acronyms. Use **initial prompt** for broader context that helps the model understand the domain and make better overall word choices.

### What Ambrose can read

In the **What Ambrose can read** section (formerly Inquire Privacy) you choose what Ambrose may read when it searches your library: on the [Ask Ambrose](inquire-mode.md) page, and in the recording chat when the agent is on. The title contains the name you gave the assistant. Transcripts are always available, since the search needs them. The other two are your choice:

- **Allow access to summaries** (on by default): Ambrose can read the summaries of your recordings, a quick way to survey a long recording before reading its transcript.
- **Allow access to your notes** (off by default): Ambrose can read your notes. Only your own notes are used, never notes on recordings shared with you.

When a content type is off, Ambrose has no tool for it. In the recording chat, your notes on the open recording are part of the question in either case. See [What Ambrose can search](ambrose.md#what-ambrose-can-search).

### Timestamps in summaries

At the top of the Prompt Options, **Include timestamps when summarizing** gives the summarization agent the time of each line of the transcript. The summary can then refer to moments in the recording, for example "the budget was approved around 00:14:30". This helps in long meetings, where finding a decision takes time.

The format dropdown below the toggle sets how each line is written. **Default** uses a compact `[hh:mm:ss] Speaker: text` layout. You can also select one of your saved transcript templates. The toggle is off by default, which keeps the prompt shorter.

Ambrose needs no setting for times: in the recording chat, answers cite passages of the transcript with their times (see [Citations](ambrose.md#citations)).

### Notes in Summaries

When **Use my notes in summaries** is on, your notes on a recording are added to the summary request as context. Notes can hold the correct spelling of names and products, an agenda, or text pasted from an email or a chat thread. The transcript remains the record of what was said. The setting is off by default, applies to summaries generated after it is turned on (regenerate a summary to use it on an existing recording), and uses only your own notes, never those of people a recording is shared with. Up to 8,000 characters of notes are sent.

### Writing Effective Prompts

Craft prompts based on how you actually use summaries. Do you extract action items for project management? Look for decisions that affect strategy? Track technical details for documentation? Your prompt should request exactly what you need for these next steps.

### Tips for Better Prompts

The expandable tips section provides guidance on crafting better instructions. Focus on clarity, structure your requests with sections or bullet points, and be specific about the level of detail you need. Remember that your prompt applies to all recordings without tag-specific prompts, so design for versatility.

## Preferences Tab

The Preferences tab is the home for display and editor behaviour settings that should follow you across devices.

### Appearance

**Interface theme.** The interface theme is the layout and style of the interface: the shape of the sidebar and its recording rows, the recording header, the transcript, the filter column of the Ask Ambrose page, surfaces, corners and type. The **Appearance** section at the top of the Preferences tab shows one card per theme, with a preview, its name and a one-line description. Clicking a card applies the theme at once, without reloading the page. The choice is saved with your account and follows you to other devices and browsers. The same cards are shown in the **Color scheme** dialog, which opens from the user menu in the header.

### Assistant

Speakr's assistant is called **Ambrose**. Under **Assistant** in the Preferences tab you can give it another name, up to 40 letters, digits, spaces, dots, hyphens or apostrophes. The name appears in the recording's assistant panel, on the Ask page, on the header button and in the monogram, which shows its first letter. Leave the field empty to go back to Ambrose. The name is saved with your account; the API and your API tokens are not affected.

The theme, the color scheme and light or dark mode are three separate settings that combine freely: every color scheme and both modes work with every theme. Neutral surfaces and shapes come from the theme, and the accent color comes from the color scheme. The **Color scheme and light or dark mode** link below the theme cards opens the color scheme dialog; light or dark mode is also switched with the sun and moon toggle in the user menu.

A new account starts with the theme and color scheme that your administrator set for new accounts. On a server with the standard configuration, that is the Cards theme with the Forest Emerald color scheme. If your account is older than this default, you see the standard theme with the blue color scheme, or the look you picked earlier in that browser, until you pick another. New themes arrive with Speakr upgrades, and the Appearance section is shown only once the server offers more than one theme. If a theme you picked is withdrawn from a server, the standard theme is shown instead.

### Language Preferences

Three language settings shape your Speakr experience. The interface language dropdown immediately transforms all menus, buttons, and messages to your chosen language; the transcription language field sets a default ISO 639-1 code that the recognition service uses to optimise accuracy when auto-detect is too slow or ambiguous; and the preferred output language controls the language of titles, summaries, and chat responses regardless of the source audio's language. Leaving the transcription language on **Auto-detect** is the right default for multilingual content.

The interface language also applies to the notices shown after account actions, such as signing in, saving settings or changing a password, and to the email verification and password reset messages. Error messages returned by the API are still in English. Text without a translation for the selected language is shown in English. Dates, times, numbers and file sizes are formatted for the interface language, independent of the browser language: month and weekday names, the decimal separator and the 12- or 24-hour clock all follow the selected language. File sizes in exported Markdown follow it as well.

These settings used to live on the Account Information tab. They moved here so all preferences that affect your day-to-day Speakr experience live in one place.

### Timezone

Dates in generated titles, such as the `{{date}}` and `{{time}}` variables of a naming template, are written in your timezone. The same timezone is used for dates in exported files and for the dates the AI is given when it writes summaries and extracts events, so "tomorrow" in a meeting is counted from your calendar day.

With **Automatic (this device)**, the default, your timezone is taken from the browser you use and updated when it changes, for example after travelling. To keep one timezone regardless of the device, choose it from the list. Dates shown on pages, such as the meeting date in the sidebar, always follow the device you are using. If no browser has reported a timezone for you yet (for example, for recordings created only through the API or the watch folder), the administrator's default timezone is used.

### Meeting Date from Filename

Voice recorders and phone apps commonly encode the recording date in the filename (`20260716_meeting.mp3`, `260716_1102.m4a`). When **Parse meeting date from filename** is enabled, Speakr extracts that date at upload time and uses it as the recording's meeting date, taking precedence over the file's timestamps and embedded metadata. This is especially useful for batch uploads of older recordings, where the meeting date would otherwise default to the upload time.

The **Filename date format** dropdown offers preset patterns — `YYYYMMDD`, `YYYYMMDD_HHMM`, `YYYY-MM-DD`, `YYMMDD_HHMM`, `YYMMDD` — plus an **Auto** mode that tries the common formats, and a **Custom pattern** option that accepts a regular expression with named groups (`(?P<year>...)`, `(?P<month>...)`, `(?P<day>...)`; `hour` and `minute` are optional). Auto mode deliberately skips the bare six-digit `YYMMDD` form, since any six digits in a filename would qualify; select that preset explicitly if your recorder uses it.

The setting is off by default. A file whose name contains no matching date keeps the existing behaviour (file timestamps, then upload time) without failing the upload, and the parsed date remains editable afterwards from the recording's details. Dates parsed from filenames are wall-clock times: browser uploads send your timezone so the stored date displays correctly everywhere, and date-only matches are anchored so the calendar date never shifts between viewers. A time followed by `Z`, as in `recording-2026-10-25T11-43-00-000Z.webm` from the browser recorder, is read as UTC. The setting also applies to files dropped into the automated processing folder.

This setting is not the same as **Naming templates** (Account → Templates), which generate a recording's *title* from template variables and can also extract text from filenames with their own patterns. The two are independent — naming templates never change the meeting date, and this setting never changes the title — but they work together: a naming template's `{{date}}`, `{{year}}`, `{{month}}` and `{{day}}` variables render the recording's meeting date, so with filename parsing enabled, a file named `20260716_call.mp3` and the "Date Prefix" naming template produces a title dated July 16, 2026 rather than the day you uploaded it.

### Transcript Display

**Show timestamps in simple view.** When enabled, a compact `mm:ss` (or `h:mm:ss` for long recordings) timestamp appears next to each speaker label in the simple transcript view, making it easier to navigate long meetings. The bubble view is unaffected. Off by default to keep the existing aesthetic for users who prefer a clean read.

### Notifications

**Email me when a transcription finishes.** When enabled, Speakr sends a message to your account email address as each recording finishes transcribing, and again if one fails permanently or the transcription service returns no text. The message names the recording, its length and how long transcription took, and links straight to it. Summaries do not send mail, since a summary follows a transcript you have already been told about.

Off by default. It is most useful for long recordings you would rather not sit and wait for; less so if you upload many files at once, because each one sends its own message.

The setting only appears when your administrator has configured email delivery and your account has an address Speakr can reach. Accounts created through single sign-on whose provider did not supply an email address do not see it, because there is nowhere to deliver to.

### Transcript Editor

**Auto-save edits in the transcript editor.** When enabled, edits made in the transcript editor are saved automatically a couple of seconds after you stop typing, with a small `Saved` indicator to confirm. When disabled (the default), saves are explicit via the Save buttons or the `Ctrl+S` keyboard shortcut. Auto-save is useful for long editing sessions where the risk of losing work outweighs the predictability of explicit writes.

### Translation

**Auto-translate new recordings.** When enabled, each new recording is translated automatically into your preferred output language once transcription finishes, so the translation is ready without another click. When disabled (the default), you generate the translation yourself with the **Generate translation** button on the translation tab.

The checkbox only appears when your administrator has enabled automatic translation for the instance. It is off by default per account, and it neither changes the recording's status nor replaces the original transcript. The target is the language set as your Preferred Chatbot, Summarization and Translation Language; when that is left on Default, your interface language is used. Translations consume the same AI tokens as a manual translation and count toward your monthly token budget, so a large batch of uploads translates every recording in the batch.

### Display

**Keyboard shortcuts.** Single keys for the recording list, the open recording and the player are on for every account. Clear the checkbox to turn them off. The keys are listed under [Keyboard Shortcuts](keyboard-shortcuts.md), and in the app with `?`.

**Audio player position (desktop only).** Choose whether the audio player sits at the **top** of a recording's page, under the title, or at the **bottom**, under the transcript and summary. A new account starts with the position that your administrator set for new accounts, by default the top. An account that never picked a position keeps the player at the bottom. The setting is saved on your account and applies to every recording. On a phone, the player always sits between the content and the bottom navigation.

**Recordings list sort.** Choose whether the recordings list opens sorted and grouped by **Date added** (the default) or by **Meeting date**. The setting is saved on your account. It is the starting point for any browser that has not picked a sort yet: choosing a sort from the Sort menu in the list overrides it, and that choice is remembered per browser.

## Shared Transcripts Tab

![Shared Transcripts](../assets/images/screenshots/settings-shared-transcripts.png)

The Shared recordings tab, also opened from **Shared recordings** in the user menu, lists everything you have shared and everything shared with you, in three sections:

- **Public links**: each recording with a public link, when you created it, whether it includes the summary and notes, and the link itself.
- **People and groups**: each recording you have shared with other users, with each person's permissions (view, edit, share). A share made through a group tag or group folder is marked as such. It lasts until the tag or folder is removed from the recording, so it has no revoke button here.
- **Shared with me**: recordings other users have shared with you, with the owner, your permissions and a link to open each one.

The last two sections appear when internal sharing is enabled. In the user menu dialog they are split into two tabs, **Shared by me** and **Shared with me**.

### Managing Share Settings

The Share Summary checkbox determines whether recipients see your AI-generated summary - useful for giving quick overviews without requiring full transcript reading. The Share Notes checkbox controls access to your personal notes, those additional thoughts and context you've added after the recording.

You can modify these settings anytime without generating new links. Toggle summary or notes on or off, and the change applies immediately to anyone accessing that link. This flexibility lets you adjust sharing based on evolving needs or feedback from recipients.

### Revoking Access

To change what a person may do, click **Change permissions**, check or clear **Allow editing** and **Allow re-sharing**, and click **Save**. To remove a person's access, click **Revoke** and then **Confirm**. Any shares that person passed on are removed too, unless the recipients also have access through another share.

For a public link, click the delete button (trash icon) to revoke access immediately. Once deleted, anyone trying to access that link sees an error message. This instant revocation provides security when you've accidentally shared with wrong parties or when access is no longer appropriate. Remember that deletion can't retrieve information already viewed or downloaded by recipients.

## Speakers Management Tab

![Speakers Management with Voice Profiles](../assets/images/screenshots/speaker-id-voice-profiles.png)
*Speakers Management with voice profile statistics, confidence scores, and voice sample playback*

The Speakers Management tab provides a comprehensive interface for managing all speakers identified across your recordings, including advanced voice profile capabilities.

### Automatic Speaker Creation

Speakers are automatically saved when you identify them during transcription editing. The system builds your library over time as you consistently name participants across recordings. When speaker diarization is enabled, Speakr automatically collects voice embeddings to build recognition profiles.

Only named speakers are saved. A placeholder of the diarization, such as `SPEAKER_00`, `Speaker 1` or `Unknown Speaker`, is never saved as a speaker and never receives a voice profile, and a saved speaker cannot be renamed to one. See [Speaker Identification](transcripts.md#speaker-identification).

### Speaker Card Information

Each speaker card displays essential information in a clean, scannable format. The speaker's name appears prominently, followed by usage statistics showing how many times they've been identified across your recordings. The last used date helps you understand which speakers are current versus historical. When a speaker was added to your library is tracked for reference.

#### Voice Profile Information

For speakers with voice recognition data, each card displays additional information:

- **Voice Profile Badge**: Shows confidence level (high/medium/low) based on the number and quality of voice samples collected
- **Sample Count**: Number of voice samples the profile is built from, and how many voice variants they form (for example the same person on a phone and in a room)
- **Voice profile**: Lists every sample with its recording, speaker label, speech time and whether it was confirmed or auto-labelled. Remove a sample that belongs to someone else and the profile is rebuilt without it
- **Voice Samples Button**: Click to hear representative audio clips of this speaker's voice for verification
- **Profile Strength Indicator**: Visual feedback showing how well the system can recognize this speaker in future recordings

The voice profile data improves speaker suggestion accuracy when identifying speakers in new recordings. When you open the speaker identification modal, Speakr analyzes voice patterns and suggests likely matches with confidence scores, making the identification process faster and more accurate over time.

### Interface Layout

The grid layout accommodates multiple speakers per row, making efficient use of screen space while maintaining readability. Each card includes action buttons - an edit icon for updating speaker details and a delete icon for removal. The red trash icon on each card provides individual deletion, while the "Delete all" button at the bottom enables bulk cleanup when needed.

### Library Statistics

At the bottom of the interface, a count shows your total saved speakers - "77 speakers saved" in the example. This helps you track the size of your speaker library and understand when maintenance might be needed.

### Maintenance Best Practices

Regular maintenance keeps your speaker library relevant. Remove speakers who no longer appear in recordings, consolidate duplicates created with slight name variations, and ensure names are consistent for better transcript coherence. Periodic reviews help keep your library manageable and useful.

### Automatic Speaker Cleanup

When recordings are deleted (either manually or through auto-deletion), Speakr automatically manages speaker voice profiles to protect your privacy:

- **Speakers with remaining recordings**: Voice profiles are preserved and continue to provide recognition suggestions
- **Speakers with no recordings**: Preserved by default. If `DELETE_ORPHANED_SPEAKERS=true` is set, they are automatically removed during the next scheduled cleanup

**Note**: Protected recordings (with protected tags) will always preserve their associated speakers.

## Tag Management Tab

![Tag Management with Enhanced Badges](../assets/images/screenshots/tag-transcription-options.png)
*Tag Management with visual badges for retention policies, protection status, sharing settings, and ASR defaults*

Tag Management transforms simple labels into powerful processing instructions. Each tag you create carries multiple capabilities - a color for visual identification, an optional custom prompt that shapes AI summaries, default ASR (Automatic Speech Recognition) settings, retention policies, and sharing configurations.

### Tag Display and Features

The interface displays your tags as cards with clear visual badges indicating their configuration. Each card shows the tag name with its color indicator, and visual badges that make it easy to see at a glance:

- **Retention Policy Badges**: Display retention periods (e.g., "90 days") or protection status (∞ infinity symbol for protected tags)
- **Sharing Badges**: Indicate if this is a group tag with auto-share capabilities (👥 users icon)
- **Language Badges**: Show custom language settings for transcription or summarization
- **Speaker Range Badges**: Display ASR defaults like "Max 10" speakers for meetings with many participants
- **Custom Prompts**: Preview of tag-specific AI summarization instructions

These visual indicators make it immediately clear which tags have special behaviors, helping you quickly select the right tags when uploading or organizing recordings.

### Creating New Tags

Creating a new tag happens through the prominent "Create tag" button. The system guides you through choosing a name, selecting a color from a palette, and optionally adding a custom prompt. The ASR defaults section appears when you're using advanced transcription services, letting you preset the expected number of speakers for recordings with this tag.

### Prompt Stacking

Tag prompts stack intelligently when multiple tags are applied. If you tag a recording with both "BSB Meetings" and "Student Meetings," both prompts combine, creating a comprehensive summary that addresses all specified requirements. This powerful stacking eliminates the need for complex single prompts trying to anticipate every combination.

### Prompt Variables

Tag and folder custom prompts may contain `{{name}}` placeholders that are filled in per recording at upload time. A "Council Meetings" tag whose prompt reads `Generate minutes for this council meeting. Agenda: {{agenda}}. Attendees: {{attendees}}.` will cause Speakr's upload form to display two input fields ("Agenda", "Attendees") whenever that tag is selected. The values are stored on the recording and substituted into the prompt at summarisation time, including on reprocessing.

**Naming rules.** Variable names use ASCII identifier characters only (letters, digits, and underscores; must start with a letter or underscore). Names with non-ASCII characters such as `{{дата}}` are not recognised as placeholders and remain in the prompt as literal text. Labels in the upload form are derived automatically (`meeting_date` becomes "Meeting date").

**Limits.** Up to 50 variables per recording, 8000 characters per value, 32000 characters total. Excess input is truncated server-side.

**Single-pass substitution.** Variables are replaced once. A value that itself contains `{{anothervar}}` is treated as literal text rather than recursively expanded.

**Drop-folder uploads.** Recordings ingested through the auto-process watch directory bypass the upload form and therefore have no opportunity to fill variables. Their stored `prompt_variables` is empty and any placeholders substitute to empty strings on the first summary run. Reprocess after upload to fill values, or use only non-templated prompts on tags applied to drop-folder content.

**Editing values after upload.** Stored variable values are editable after the fact. Open the reprocess modal on the recording, change the values, and reprocess — the updated values are applied and substituted into the prompt on the next summary run. There is no need to re-upload the recording.

**Where variables are surfaced.** The upload form mirrors the same priority chain that the summarisation task uses to pick a prompt. The first non-empty layer wins and its variables become inputs on the form: selected tags first, then the selected folder, then your personal summary prompt, then the site default set by the admin. Lower layers are not scanned because their prompt would not run.

**Drop-folder ingest is the exception.** Recordings ingested through the auto-process watch directory bypass the upload form entirely, so any tag prompt with placeholders attached to such a recording silently substitutes to empty strings. Tag Management surfaces a warning when a tag is configured as a watch-folder tag and its custom prompt contains `{{...}}` placeholders. Either keep watch-folder tags variable-free, or reprocess after upload to fill the values.

### ASR Defaults

The ASR defaults feature is particularly valuable for consistent meeting types. Setting "Max 10" for a "Court Action" tag ensures the transcription service looks for up to 10 distinct speakers, improving accuracy for multi-party proceedings. A "One-on-One" tag might default to exactly 2 speakers, while a "Webinar" tag could specify 1-3 speakers.

### Transcription Hints (Hotwords & Initial Prompt)

Tags can also carry default **hotwords** and an **initial prompt** to improve transcription accuracy for specialized content. Hotwords are comma-separated terms the transcription engine should prioritize (e.g., brand names, acronyms, technical jargon). The initial prompt provides broader context about the recording content, helping the engine make better word choices.

For example, a "Medical Rounds" tag might include hotwords like `epinephrine, tachycardia, intubation` and an initial prompt like "This is a medical team discussion about patient care in an ICU setting." When you upload a recording with this tag, these hints are automatically applied during transcription.

These values follow a precedence hierarchy: upload form values take highest priority, then tag defaults, then folder defaults, then your personal defaults in [account settings](#custom-prompts-tab). They apply both at initial upload and when reprocessing the transcription, so changes you make to a tag's defaults will affect future reprocesses of recordings carrying that tag.

### Default Transcription Model

When your administrator has configured a transcription model list (via `TRANSCRIPTION_MODELS_AVAILABLE` or the admin dashboard), tag and folder edit forms gain a **Default transcription model** dropdown. Recordings with that tag will use the chosen model unless the upload form, folder default, or admin default overrides it. The precedence chain mirrors hotwords and initial prompt: per-upload selection beats tag default beats folder default beats admin default.

If a tag has a default model set and the model is later removed from the configured list, the edit form shows a compact warning so you know to pick a replacement. The default itself is preserved in the database in case the model is added back, and the precedence chain falls through to the next available layer in the meantime.

### Managing Tags

Edit and delete buttons on each card provide full control. Edit to refine prompts based on results, adjust colors for better organization, or update ASR defaults as meeting patterns change. Delete removes tags no longer needed, though this doesn't affect recordings already tagged - they retain their labels for historical accuracy.

## API Tokens Tab

The API Tokens tab enables programmatic access to your Speakr instance through personal access tokens. These tokens allow automation tools, scripts, and custom integrations to authenticate as your user account.

### Creating Tokens

Click the **Create token** button to generate a new token. You'll provide a descriptive name (like "n8n automation" or "CLI scripts") and choose an expiration period, which is set to 90 days by default (**Never expires** can still be selected). The token value is shown only once after creation - copy it immediately and store it securely.

!!! warning "Token Security"
    Treat API tokens like passwords. They provide full access to your account. Never share tokens publicly, commit them to version control, or expose them in client-side code.

### Token Display

Active tokens appear as compact cards showing:

- **Name** - The descriptive name you assigned
- **Status badge** - Active (green), expired (yellow), or revoked (red)
- **Created date** - When the token was created
- **Last used** - When the token last authenticated a request
- **Expiration** - When the token expires, or "No expiration" for permanent tokens

### Using Tokens

Tokens can authenticate API requests through multiple methods:

```bash
# Authorization header (recommended)
curl -H "Authorization: Bearer YOUR_TOKEN" https://speakr.example.com/api/recordings

# X-API-Token header
curl -H "X-API-Token: YOUR_TOKEN" https://speakr.example.com/api/recordings

# Query parameter (deprecated; GET requests only)
curl "https://speakr.example.com/api/recordings?token=YOUR_TOKEN"
```

The Authorization header is the preferred form. The `?token=` query parameter is deprecated and is accepted only on `GET` requests; a request with any other method that carries the token only in the query string gets `401`.

### Revoking Tokens

Click the trash icon on any token card to revoke it immediately. Revoked tokens stop working instantly and cannot be restored. Create a new token if you need continued access.

### Best Practices

- Use descriptive names to track each token's purpose
- Set an expiration date on every token
- Revoke tokens you no longer need
- Create separate tokens for different integrations
- Never share tokens between users - each person should create their own

For detailed API documentation and integration examples, see the [API Tokens Guide](api-tokens.md).

## Webhooks Tab

The Webhooks tab lets you register your own endpoints to receive HTTP notifications when your recordings change — for example when transcription completes or a summary is generated. Each delivery is signed with HMAC-SHA256 so your receiver can verify it came from Speakr, and failed deliveries are retried automatically. Add, edit, and remove subscriptions directly from this tab.

For the full event list, payload formats, and signature verification details, see the [Webhooks admin guide](../admin-guide/webhooks.md).

## About Tab

![About](../assets/images/screenshots/settings-about.png)

The About tab presents a comprehensive overview of your Speakr installation, combining version information, system configuration, feature highlights, and quick access to resources.

### Version Information

At the top, the Speakr logo and tagline "Audio transcription and notes" remind you of the system's core purpose. The version badge (v0.9.0 in the example) immediately tells you which release you're running, essential information for troubleshooting and determining available features.

### System Configuration

This section provides complete transparency about your instance's capabilities. The Large Language Model field shows which AI model powers summaries and chat - here using the OpenRouter endpoint with a specific model. The Speech Recognition section details your transcription setup, showing whether you're using the standard Whisper API or advanced ASR endpoints. When ASR is enabled, you'll see additional configuration like the endpoint URL, indicating enhanced transcription features including speaker diarization.

### Project Links

Quick access buttons connect you to essential resources. The GitHub Repository button links to source code, issues, and releases - your primary channel for reporting bugs or requesting features. The Docker Hub button provides access to official container images for deployment and updates. The Documentation button opens setup guides and user manuals, ensuring help is always one click away.

### Key Features

Colorful cards remind you of Speakr's core capabilities. Audio Transcription highlights support for both Whisper API and custom ASR with high accuracy. AI Summarization emphasizes the OpenRouter and Ollama integrations for flexible, powerful summary generation. Speaker Diarization showcases the ability to identify and label different speakers automatically. Interactive Chat demonstrates the conversational AI capabilities for exploring transcripts. Library search highlights questions across all recordings. Sharing & Export emphasizes the ability to share recordings and export to various formats.

### Using This Information

This information-rich tab serves multiple purposes. For troubleshooting, it provides all the version and configuration details support groups need. For planning, it shows which features are available and properly configured. For learning, it links to all the resources needed to master Speakr's capabilities.

## Privacy and Security Considerations

Your account settings contain sensitive information that shapes your entire Speakr experience. The custom prompts you create might reveal organizational priorities or confidential project details. Speaker profiles could indicate who you meet with regularly. Share histories show what information you've distributed.

Always log out when using shared computers. Speakr maintains sessions for convenience, but this means anyone with access to your browser can access your account. The logout button in the user menu immediately terminates your session and requires re-authentication.

Review your shared recordings regularly. Links you created months ago might still be active, providing access to outdated or sensitive information. The Shared recordings tab makes this review easy - scan through periodically and revoke anything no longer needed.

Consider the implications of language settings in international contexts. If you set Chinese as your interface language on a shared computer, the next user might struggle to navigate. Similarly, output language settings affect all AI interactions, so ensure they match your actual needs.

## Optimizing Your Settings

The most effective Speakr setup evolves with your needs. Start with basic configuration - your name, language preferences, and a simple custom prompt. As you become comfortable, add tags for organization, refine your prompts for better summaries, and build your speaker library for improved transcripts.

Monitor which settings you actually use. If you never change certain preferences, they're probably fine at defaults. If you constantly adjust others, consider whether different base settings would reduce this friction. Your settings should work for you, not require constant attention.

Share successful configurations with your group. If you've crafted an excellent prompt for technical summaries, share it with colleagues who might benefit. If your tag taxonomy works well, document it for others to adopt. Collective improvement benefits everyone.

Remember that settings are tools for productivity, not endpoints themselves. The goal isn't perfect configuration but effective recording management. When your settings fade into the background and Speakr just works how you expect, you've achieved the right balance.

---

Next: Return to [User Guide](index.md) →