# Folders

Folders provide a simple way to organize your recordings into logical groups. Unlike tags which can be applied multiple times to categorize content, each recording belongs to exactly one folder (or no folder). Think of folders like directories on your computer - a clean, hierarchical way to keep related recordings together.

## Enabling Folders

Folders are disabled by default. An administrator must enable the feature before users can create and use folders.

**For Administrators:**

1. Go to Admin Panel → System Settings
2. Find the `enable_folders` setting and set it to `true`
3. Save changes

Or set the environment variable:
```bash
ENABLE_FOLDERS=true
```

Once enabled, all users will see folder management options in their Account Settings and folder selectors throughout the interface.

## Creating Folders

Access folder management from **Account Settings → Folders** tab.

Click **Create folder** to add a new folder. Each folder has:

- **Name** - A short, descriptive name (required)
- **Color** - Visual identifier shown on folder pills and in the sidebar

### Folder Settings

Each folder can have custom settings that apply to recordings placed in it:

| Setting | Description |
|---------|-------------|
| **Custom prompt** | AI summarization instructions specific to this folder. May include `{{name}}` placeholders that are filled at upload time — see [Prompt Variables](settings.md#prompt-variables) |
| **Title prompt** | Instructions for the AI-generated titles of recordings in this folder. A tag's title prompt takes priority; see [Title Prompt](settings.md#title-prompt) |
| **Default language** | Transcription language for new recordings |
| **Default transcription model** | Model the transcription connector should use when an admin has configured `TRANSCRIPTION_MODELS_AVAILABLE` (or curated a list from the admin dashboard) |
| **Min/Max Speakers** | Speaker count hints for ASR diarization |
| **Hotwords** | Comma-separated vocabulary hints for transcription accuracy |
| **Initial prompt** | Context description to guide transcription |
| **Retention days** | Override global retention for recordings in this folder |
| **Protection** | Exempt folder contents from auto-deletion |

These settings work like tag settings - when you add a recording to a folder, the folder's custom prompt and ASR settings are applied during processing. Tag-level defaults take precedence over folder-level defaults; per-upload selections take precedence over both.

### Nested Folders

A folder can sit inside another folder. To create a subfolder:

1. Open **Account Settings → Folders** and click **Create folder**, or click the edit button on an existing folder
2. Choose the folder it belongs in under **Parent folder**; **None (top level)** keeps it at the top
3. Save the folder

The **Parent folder** field appears once there is a folder it could go into. For a group folder, choose the group on the **Sharing** tab first: the list then shows only that group's folders. When you edit a folder, the folder itself and its own subfolders are left out of the list.

Subfolders appear right after their parent. In the sidebar folder selector and the other folder dropdowns, a subfolder shows its full path, such as `Projects / Alpha / 2026`; in the folder menu of a recording and in **Move to folder** it is indented under its parent. In Account Settings each subfolder's card shows the names of the folders above it. Through the API, set `parent_id` when you create or update a folder (see [Folders in the API reference](api-reference.md#create-folder)).

- **Same scope** - A personal folder can only sit inside another of your personal folders, and a group folder only inside a folder of the same group
- **No loops** - A folder cannot be moved inside itself or inside one of its own subfolders
- **Deleting a parent** - Its subfolders move up one level, to the deleted folder's parent; their own subfolders stay where they are
- **Changing a group** - A folder that has subfolders keeps its group; move the subfolders out first
- **Names** - The existing name rules apply across all levels, so two parents cannot each hold a subfolder with the same name
- **Counts** - `recording_count` counts only the recordings directly in a folder; the folder endpoints also return `total_recording_count`, which adds the recordings in all subfolders

Existing folders become top-level folders when you upgrade.

## Using Folders

### Sidebar Folder Selector

The sidebar includes a folder dropdown at the top. Use it to:

- **Filter by folder** - Select a folder to show only recordings in that folder
- **View all recordings** - Select "All folders" to see everything
- **View unfiled** - Select "No folder" to see recordings not in any folder
- **Include subfolders** - When the selected folder has subfolders, tick **Include subfolders** below the selector to list their recordings too; it is off by default

### Moving Recordings to Folders

There are several ways to assign recordings to folders:

1. **During upload** - Select a folder before uploading
2. **From recording detail** - Use the folder selector in the recording header
3. **Bulk operations** - Select multiple recordings and use the folder action

### Folder Pills

Recordings display a small colored pill showing their folder name. This appears in:

- The sidebar recording list
- The recording detail header
- Search results

Click the pill to quickly filter to that folder.

### Title Bar Icon

When viewing a recording that's in a folder, a folder icon appears in the title bar next to the recording title. Click it to see folder details or change the folder assignment.

## Group Folders

If your organization uses groups, folders can be group-scoped:

- **Personal folders** - Visible only to you
- **Group folders** - Shared with all group members

Group folders work like group tags with auto-sharing:

| Setting | Description |
|---------|-------------|
| **Auto-share with group members** | Automatically share recordings with group members when moved to this folder |
| **Share with group admins** | Also share with group administrators |

When you move a recording to a group folder with auto-share enabled, all group members receive access automatically.

These shares last as long as the recording stays in the folder. When you move the recording out of the folder, delete the folder, or move the folder to another group, the members lose the access they had through the folder. When you move the folder to another group, the recordings in it are shared with the new group's members as the folder's settings say. A member keeps access they still have through a group tag on the recording, and a share you made by hand. A member who leaves the group loses the access they had through the group's folders and tags. Their personal notes are kept and return if the recording is shared with them again.

A change of the folder's sharing settings applies to the recordings already in it. Members the new settings include gain access, whatever the processing status of the recording, and members they leave out lose the access the folder gave them. The change covers the folder's own recordings; a subfolder keeps its own settings. Moving a folder to a group requires admin rights in that group, and edit access to every recording in it that belongs to another user.

## Folders vs Tags

Both folders and tags help organize recordings, but they serve different purposes:

| Aspect | Folders | Tags |
|--------|---------|------|
| **Assignment** | One folder per recording | Multiple tags per recording |
| **Purpose** | Primary organization | Categorization and filtering |
| **Hierarchy** | Folders can contain subfolders | Flat list |
| **Settings** | Custom prompt, ASR, retention | Custom prompt, ASR, retention |
| **Visual** | Pill badge, sidebar filter | Colored badges |

**Use folders for:** Project-based organization, client separation, meeting types

**Use tags for:** Cross-cutting concerns, status tracking, topic categorization

You can use both together - put a recording in the "Client A" folder and tag it with "Action Items" and "Follow-up Needed".

## Best Practices

### Naming Conventions

Choose clear, consistent folder names:

- **By project:** "Website Redesign", "Q1 Planning", "Product Launch"
- **By client:** "Acme Corp", "Beta Inc", "Gamma LLC"
- **By type:** "Team Standups", "Client Calls", "Interviews"

### Folder Prompts

Use folder-specific prompts for consistent summaries:

```
For client meetings, create a summary with:
- Discussion topics
- Client requests and concerns
- Commitments made
- Next steps with owners
```

### Retention Strategies

Set folder-level retention to match content needs:

- **Active projects:** No retention limit
- **Completed projects:** 90 days after project close
- **Routine meetings:** 30 days
- **Compliance recordings:** Use protection flag

---

Next: [Tags](settings.md#tag-management-tab) →
